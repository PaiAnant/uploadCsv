/*global QUnit*/

sap.ui.define([
	"com/csv/UploadCsv/controller/First.controller"
], function (oController) {
	"use strict";

	QUnit.module("First Controller");

	QUnit.test("I should test the First controller", function (assert) {
		var oAppController = new oController();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});