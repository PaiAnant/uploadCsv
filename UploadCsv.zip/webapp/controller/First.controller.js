sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"com/csv/UploadCsv/lib/zip",
	"com/csv/UploadCsv/lib/xlsx"
], function (Controller, JSONModel, ZIP, xlsx) {
	"use strict";

	return Controller.extend("com.csv.UploadCsv.controller.First", {
		onInit: function () {
			var jData = {};
			var oModel = new JSONModel(jData);
			this.getView().setModel(oModel);
			this.getView().byId("TableId").setVisible(false);
		},

		handleUploadPress: function (oEvt) {

		},

		handleUploadComplete: function (oEvent) {
			var fUrl = oEvent.getSource().oFileUpload;
			var reader = new FileReader();
			reader.onload = function (oEvt) {

				var workbook = XLSX.read(oEvt.target.result, {
					type: 'binary'
				});

				workbook.SheetNames.forEach(function (sheetName) {
					var XL_row_object = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
					this.getView().getModel().setProperty("/Products", XL_row_object);
					// var json_object = JSON.stringify(XL_row_object);
				}.bind(this));

				this.getView().byId("TableId").setVisible(true);

				// var aArray = oEvt.target.result.split("\n");
				// if (aArray[aArray.length - 1] === "") {
				// 	aArray.pop();
				// }
				// var header = aArray[0].split(",");
				// var record = {},
				// 	data = [];
				// var itemRow;
				// var itemData = [];
				// for (var i = 1; i < aArray.length; i++) {
				// 	itemRow = aArray[i].split(",");
				// 	itemData.push(itemRow);
				// 	for (var j = 0; j < header.length; j++) {
				// 		record[header[j]] = itemRow[j];
				// 	}

				// 	data.push(record);
				// 	record = {};
				// }

				// var columnArr = [];
				// var oStringResult = JSON.stringify(data);
				// for (var key in data[0]) {
				// 	columnArr.push(key);
				// }
				// var itemArr = [];
				// for (var row in data[0]) {
				// 	itemArr.push(row);
				// }

				// var oFinalResult = JSON.parse(oStringResult.replace(/\\r/g, ""));

				// var oTable = this.getView().byId("TableId");
				// oTable.removeAllColumns();
				// oTable.removeAllItems();
				// for (var k = 0; k < columnArr.length; k++) {
				// 	oTable.addColumn(new sap.m.Column({
				// 		header: new sap.m.Title({
				// 			text: columnArr[k]
				// 		})
				// 	}));
				// }
				// for (var l = 0; l < itemData.length; l++) {
				// 	var oColumn = new sap.m.ColumnListItem({});
				// 	for (var m = 0; m < itemData[l].length; m++) {
				// 		var test = itemData[l][m];
				// 		oColumn.addCell(new sap.m.Text({
				// 			text: test
				// 		}));
				// 		oTable.addItem(oColumn);
				// 	}
				// }
				// this.getView().getModel().setProperty("/Products", oFinalResult);
				// this.getView().byId("TableId").setVisible(true);
			}.bind(this);
			// reader.readAsText(fUrl.files[0]);
			reader.readAsBinaryString(fUrl.files[0]);
		}

	});
});